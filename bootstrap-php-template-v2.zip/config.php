<?php
$site_name = "Site Name";
?>